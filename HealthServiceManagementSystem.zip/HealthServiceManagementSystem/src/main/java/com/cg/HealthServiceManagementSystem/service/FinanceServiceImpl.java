package com.cg.HealthServiceManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.HealthServiceManagementSystem.entity.Finance;
import com.cg.HealthServiceManagementSystem.repository.IFinanceRepository;

@Service
public class FinanceServiceImpl implements IFinanceService {

	@Autowired
	IFinanceRepository financeService;

	// save
	@Override
	public Finance save(Finance finance) {
		return financeService.save(finance);
	}

	// findAllFinanceDetails
	@Override
	public List<Finance> findAllFinanceDetails() {
		return financeService.findAll();
	}

	// findByPatientId
	@Override
	public Finance findByPatientId(int id) {
		Finance fin = financeService.findById(id).get();
		return fin;
	}

	// deleteFinanceByFinanceId
	@Override
	public Finance deleteFinanceByFinanceId(int id) {
		Finance fin = financeService.findById(id).get();
		financeService.deleteById(id);
		return fin;
	}

	// update
	@Override
	public Finance update(Finance finance) {
		Finance fin = financeService.findById(finance.getPatientId()).get();
		fin.setPatientName(finance.getPatientName());
		// f.setDept(finance.getDept());
		return financeService.save(fin);
	}

	// custom method
	// findByFinanceIdOrderByPatientName
	@Override
	public List<Finance> findByFinanceIdOrderByPatientName(int financeId) {
		// Finance f =
		// financeService.findByFinanceOrderByPatientName(patientName).get();
		// return financeService.findByFinanceOrderByPatientName(patientName);
		return financeService.findByFinanceIdOrderByPatientName(financeId);
	}

}