package com.cg.HealthServiceManagementSystem.exceptions;

public class FinanceErrorMessage {

	private int status; // error code 404
	private String message; // finance not found with the given id:
	private String timeStamp;

	// Constructors
	public FinanceErrorMessage(int status, String message, String timeStamp) {
		super();
		this.status = status;
		this.message = message;
		this.timeStamp = timeStamp;
	}

	// getters and setters
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

}
