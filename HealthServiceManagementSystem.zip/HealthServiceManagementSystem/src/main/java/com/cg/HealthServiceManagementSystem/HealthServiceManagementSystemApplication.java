package com.cg.HealthServiceManagementSystem;

import org.apache.logging.log4j.LogManager;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cg.HealthServiceManagementSystem.repository.IFinanceRepository;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class HealthServiceManagementSystemApplication {

	org.apache.logging.log4j.Logger logger = LogManager.getLogger();

	public static void main(String[] args) {
		SpringApplication.run(HealthServiceManagementSystemApplication.class, args);
	}

	// Enable Swagger
	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.cg.HealthServiceManagementSystem")).build();
	} // http://localhost:8081/swagger-ui/

	
	//Command Line Runner
	@Bean
	CommandLineRunner cmdLineRunner(IFinanceRepository financeService) {
		return args -> {
			/*
			 * for (Finance f : financeService.findByFinanceOrderByPatientName("Deepa")) {
			 * logger.info(f);
			 */
			logger.info(financeService.findByFinanceIdOrderByPatientName(1008));
			logger.info(financeService.getFinanceByName("Ramya"));

			// Custom Query
			logger.info(financeService.getFinanceByNameAndId("Soham", 1002));

			// Native Query
			logger.info(financeService.getFinanceByNameOrId("Ahmed", 1003));

		};
	}

}
