package com.cg.hsms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hsms.entity.Finance;
import com.cg.hsms.service.IFinanceService;

@RestController
@CrossOrigin
public class FinanceController {

	@Autowired
	IFinanceService financeService;

	// WRITE
	// save
	@PostMapping("/finance")
	public Finance addFinance(@RequestBody Finance finance) {
		return financeService.save(finance);
	}

	// Read
	// findAllFinanceDetails
	@GetMapping("/finance")
	public List<Finance> findAllFinanceDetails() {
		return financeService.findAllFinanceDetails();
	}

	// findByPatientId
	@GetMapping("/finance/id/{patientid}")
	public Finance findByPatientId(@PathVariable("id") int patientId) {
		return financeService.findByPatientId(patientId);
	}

	// DELETE
	// deleteFinanceByFinanceId
	@DeleteMapping("/finance/{patientid}")
	public Finance deleteFinanceByFinanceId(@PathVariable("id") int patientId) {
		return financeService.deleteFinanceByFinanceId(patientId);
	}

	// UPDATE
	// Updating specific property
	// updateFinance
	@PatchMapping("/finance/{patientid}")
	public Finance updateFinance(@PathVariable("id") int id, @RequestBody Finance finance) {
		return financeService.update(finance);
	}

	// custom method
	// findByFinanceOrderByPatientName
	@GetMapping("/finance/financeId/{financeId}")
	public List<Finance> findByFinanceIdOrderByPatientName(@PathVariable("name") int financeId) {
		return financeService.findByFinanceIdOrderByPatientName(financeId);
	}
}
