package com.cg.hsms.service;

import java.util.List;

import com.cg.hsms.entity.Finance;

public interface IFinanceService {

	// save
	Finance save(Finance finance);

	// findAllFinanceDetails
	List<Finance> findAllFinanceDetails();

	// findByPatientId
	Finance findByPatientId(int id);

	// deleteFinanceByFinanceId
	Finance deleteFinanceByFinanceId(int id);

	// update
	Finance update(Finance finance);

	// custom methods
	// find finance based on patient name and display in asc order
	List<Finance> findByFinanceIdOrderByPatientName(int financeId);
}
