package com.cg.spring.hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsApplicationTests {

	@Test
	void contextLoads() {
	}

}