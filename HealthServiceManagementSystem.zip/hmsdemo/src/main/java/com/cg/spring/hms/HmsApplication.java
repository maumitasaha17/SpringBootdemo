package com.cg.spring.hms;

import org.apache.logging.log4j.LogManager;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cg.spring.hms.repository.IEmployeeRepository;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class HmsApplication {
	org.apache.logging.log4j.Logger logger = LogManager.getLogger(); 
	
	public static void main(String[] args) {
		SpringApplication.run(HmsApplication.class, args);
	}
	
	//Enable Swagger
	   @Bean
	   public Docket productApi() {
	      return new Docket(DocumentationType.SWAGGER_2).select()
	         .apis(RequestHandlerSelectors.basePackage("com.cg.hms")).build();
	   }
	   
	
	
	
		//For testing
	//using command line runner u can test the cases alone without using postman
	//command line runner is and interface
		@Bean
		CommandLineRunner cmdLineRunner(IEmployeeRepository empRepo) {
			return args->{
			/*	logger.info(empRepo.findByDeptOrderByEmpName("IT"));
				//logger.debug(empRepo.findByDeptOrderByEmpNameDesc("IT"));
		};*/
		logger.info(empRepo.getEmployeeByName("Ram"));
		logger.info(empRepo.getEmployeeByNameAndDept("IT","Sam"));
		logger.info(empRepo.getEmployeeByNameOrDept("IT","Sam"));
			};
	}

}
