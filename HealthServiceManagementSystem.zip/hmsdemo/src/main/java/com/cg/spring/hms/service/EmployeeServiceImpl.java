package com.cg.spring.hms.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.hms.entity.Employee;
import com.cg.spring.hms.repository.IEmployeeRepository;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeRepository empRepo;
	
	//Here Methods are predefined methods
	//If i want to write my own custom methods you can wrtie it in repository
	@Override
	public Employee save(Employee employee) {
		return empRepo.save(employee);
	}
	

	 @Override
	public List<Employee> findAll() {
		return empRepo.findAll();
	}
	
	@Override
	public Employee findByEmpId(int id) {
		Employee emp = empRepo.findById(id).get();
		return emp;
	}

	

	@Override
	public Employee deleteByEmpId(int id) {
		Employee emp = empRepo.findById(id).get();
		empRepo.deleteById(id);
		return emp;
	}

	@Override
	public Employee update(Employee employee) {
		Employee emp = empRepo.findById(employee.getEmpId()).get();
		emp.setEmpName(employee.getEmpName());
		emp.setDept(employee.getDept());
		return empRepo.save(emp);
	}

	

	@Override
	public Employee updateEmpName(int empId, Employee employee) {
		//Employee emp = empRepo.findById(empId).get();
		Optional<Employee> emp = empRepo.findById(empId);
		if(emp.isPresent()) {
			emp.get().setEmpName(employee.getEmpName());
		}
		
		return empRepo.save(emp.get());
	}

	@Override
	public Employee updateEmpDept(int empId, Employee employee) {
		Employee emp = empRepo.findById(empId).get();
		emp.setDept(employee.getDept());
		return empRepo.save(emp);
	}

	//custom method
	//findByEmpName
	@Override
	public Employee findByEmpName(String name) {
		return empRepo.findByEmpName(name);
	}

	//findAllEmpByDept
	@Override
	public List<Employee> findAllEmpByDept(String deptName){
		return empRepo.findAllEmpByDept(deptName);
	}

	//FIND BY Emp Id is less than 150
	@Override
	public List<Employee> findByEmpIdLessThan(int id) {
		return empRepo.findByEmpIdLessThan(id);
	}
	

}