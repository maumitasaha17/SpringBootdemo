package com.cg.spring.hms.controller;

public @interface UpdateMapping {

}
