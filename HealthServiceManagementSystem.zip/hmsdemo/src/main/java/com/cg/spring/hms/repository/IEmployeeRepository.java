package com.cg.spring.hms.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.spring.hms.entity.Employee;

// Spring Data JPA
// Spring Data REST

/*
 * Product -Product, ProductController, ProductService & ProductRepository
 * Address
 * Profile
 * Dept
 * 
 * PRODUCT 	- endpoints/URI	- Uniform Resource Identifier 
 * GET 		- /product 		- all products
 * GET 		- /product/{id} - Specific Product
 * POST 	- /product 		- create new product
 * PUT 		- /product/{id} - Updating existing product details based on id
 * DELETE 	- /product/{id} - Delete product based on id
 * 
 * WITHOUT SPRING DATA REST
 * Product- ProductController - ProductService- ProductRepository
 * 
 * WITH Spring Data REST - provides basic endpoints automatically
 * Product- ProductController
 * 
 * 
 * ......................................................................................
 * 
 * 
 * 
 * 
 * 
 */








@Repository
public interface IEmployeeRepository extends JpaRepository<Employee, Integer > {
	//Custom Method
	//Customise methods will be written in repository
	//find by name
	Employee findByEmpName(String name);

	//SEARCH EMPLOYEES BASED ON DEPT
	List<Employee> findAllEmpByDept(String deptName);

	//FIND BY Emp Id is less than 150
	List<Employee> findByEmpIdLessThan(int id);
	
	//find emplloyees based on dept and display in asc order
	List<Employee> findByDeptOrderByEmpName(String deptName);

	//find emplloyees based on dept and display in desc order
		List<Employee> findByDeptOrderByEmpNameDesc(String deptName);
		
		
	//Custom Queries
	//find employee based on name
	@Query("select e from Employee e where e.empName=:n")
	public Employee getEmployeeByName(@Param("n")String empName);
	
	//find employee based on name and dept
	//pass 2 values
	@Query("select e from Employee e where e.empName=:n and e.dept=:d")
	public Employee getEmployeeByNameAndDept(@Param("n")String empName, @Param("d")String dept);
	
	//Native QUERIES - if not working with JPA queries .... instead of class name you have to give table name
	@Query(value="select e from employee e where e.emp_name=:n or e.dept=:d", nativeQuery=true)
	public Employee getEmployeeByNameOrDept(@Param("n")String empName, @Param("d")String dept);
	
}
