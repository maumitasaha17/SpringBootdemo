package com.cg.spring.hms.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	@GetMapping("/") //is the URL
	public String hello() {
		return "Hello World!";
	}
}
