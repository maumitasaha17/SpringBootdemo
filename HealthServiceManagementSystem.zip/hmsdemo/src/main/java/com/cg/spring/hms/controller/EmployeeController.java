package com.cg.spring.hms.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.hms.entity.Employee;
import com.cg.spring.hms.service.IEmployeeService;
/*
 * RESTFULL -GET<POST<PUT<DELETE
 * LOGGER 
 * QUERIES
 * NATIVE QUERIES
 * 
 * 
 * 
 * 
 * 
 */
@RestController
public class EmployeeController {
	
	@Autowired
	IEmployeeService empService;
	
	// WRITE
	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody Employee employee) {
		return empService.save(employee);
	}
	
	//Read
	@GetMapping("/employee")
	public List<Employee> findAllEmployees() {
		return empService.findAll();
	}
	@GetMapping("/employee/id/{id}")
	public Employee findEmployeeById(@PathVariable("id")int empId) {
		return empService.findByEmpId(empId);
	}
	
	//custom method find by name
	@GetMapping("/employee/name/{name}")
	public Employee findByEmpName(@PathVariable("name")String name) {
		return empService.findByEmpName(name);
	}

	//custom method find all emp by dept
		@GetMapping("/employee/{dept}")
		public List<Employee> findAllEmpByDept(@PathVariable("dept")String deptName) {
			return empService.findAllEmpByDept(deptName);
		}
		
		//FIND BY Emp Id is less than 150
		@GetMapping("/employee/lt/{id}")
		public List<Employee> findByEmpIdLessThan(@PathVariable("id")int id) {
			return empService.findByEmpIdLessThan(id);
		}
		
	// DELETE
	@DeleteMapping("/employee/{id}")
	public Employee deleteEmployee(@PathVariable("id") int empId) {
		return empService.deleteByEmpId(empId);
	}
	
	// UPDATE
	// Updating specific property
	@PatchMapping("/employee/{id}")
	public Employee updateEmpName(@PathVariable("id") int id, @RequestBody Employee employee) { // first is path variable the url i.e id and then comes the body i.e employe contains employee details
		return empService.updateEmpName(id, employee);
	}
	
	@PatchMapping("/employee/dept/{id}")
	public Employee updateEmpDept(@PathVariable("id") int id, @RequestBody Employee employee) {
		return empService.updateEmpDept(id, employee);
	}
	
	// Update
	@PutMapping("/employee/{id}") 
	public Employee updateEmployee(@PathVariable("id") int id, @RequestBody Employee employee) {
		return empService.update(employee);
	
	//put and patch have same property of updating into data base
		//In put we need to specify all the properties in potman
		//In patch we can pass only one property in postman. no need to specify all the properties in postman 
	}
	
}

