package com.cg.spring.hms.service;
import java.util.List;
import com.cg.spring.hms.entity.Employee;

public interface IEmployeeService {
	//method signature that needs t o be implemented in employee service 
	//predefined method
	Employee save(Employee employee); // saving employee and return type is Employee
	List<Employee> findAll();
	Employee findByEmpId(int id); //searching for emp by id so return type will be employee


	Employee deleteByEmpId(int id);
	Employee update(Employee employee);
	Employee updateEmpName(int empId, Employee employee);
	Employee updateEmpDept(int empId, Employee employee);
	
	//custom methods - own methods
	Employee findByEmpName(String name);

	//SEARCH EMPLOYEES BASED ON DEPT
	List<Employee> findAllEmpByDept(String deptName);

	//FIND BY Emp Id is less than 150
	List<Employee> findByEmpIdLessThan(int id);

}